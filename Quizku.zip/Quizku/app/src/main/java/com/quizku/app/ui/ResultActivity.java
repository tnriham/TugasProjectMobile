package com.quizku.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.quizku.app.R;
import com.quizku.app.util.LocaleHelper;
import com.quizku.app.util.Prefs;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        super.attachBaseContext(LocaleHelper.setLocale(newBase, Prefs.getLang(newBase)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView tvScore = findViewById(R.id.tvScore);
        Button btnUlangi = findViewById(R.id.btnUlangi);

        int score = getIntent().getIntExtra("score", 80);
        int total = getIntent().getIntExtra("total", 100);

        tvScore.setText(score + "/" + total);

        // "Ulangi" balik ke menu
        btnUlangi.setOnClickListener(v -> {
            Intent i = new Intent(ResultActivity.this, MenuActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });
    }
}

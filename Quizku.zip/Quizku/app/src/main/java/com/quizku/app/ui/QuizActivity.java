package com.quizku.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.quizku.app.R;
import com.quizku.app.model.Question;
import com.quizku.app.model.QuestionBank;
import com.quizku.app.util.LocaleHelper;
import com.quizku.app.util.Prefs;

import java.util.List;

public class QuizActivity extends AppCompatActivity {

    private static final int TOTAL_QUESTIONS = 5;
    private static final long QUESTION_TIME_MS = 60_000; // 60s

    private TextView tvProgress, tvTimer, tvQuestion;
    private Button btnA, btnB, btnC, btnD, btnKembali;

    private List<Question> questions;
    private int index = 0;
    private int correct = 0;

    private CountDownTimer timer;
    private long timeLeft = QUESTION_TIME_MS;

    @Override
    protected void attachBaseContext(Context newBase) {
        super.attachBaseContext(LocaleHelper.setLocale(newBase, Prefs.getLang(newBase)));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        // init view (ID sesuai XML UI lo)
        tvProgress = findViewById(R.id.tvProgress);
        tvTimer = findViewById(R.id.tvTimer);
        tvQuestion = findViewById(R.id.tvQuestion);

        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        btnC = findViewById(R.id.btnC);
        btnD = findViewById(R.id.btnD);
        btnKembali = findViewById(R.id.btnKembali);

        // ambil data soal
        questions = QuestionBank.getQuestions(this);
        if (questions == null || questions.isEmpty()) {
            Toast.makeText(this, "Soal kosong!", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        // event pilihan jawaban
        btnA.setOnClickListener(v -> answer(0));
        btnB.setOnClickListener(v -> answer(1));
        btnC.setOnClickListener(v -> answer(2));
        btnD.setOnClickListener(v -> answer(3));

        // tombol kembali -> menu
        btnKembali.setOnClickListener(v -> {
            stopTimer();
            Intent i = new Intent(QuizActivity.this, MenuActivity.class);
            i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            finish();
        });

        showQuestion();
    }

    private void showQuestion() {
        if (index >= TOTAL_QUESTIONS || index >= questions.size()) {
            finishQuiz();
            return;
        }

        Question q = questions.get(index);

        tvProgress.setText((index + 1) + "/" + TOTAL_QUESTIONS);
        tvQuestion.setText(q.question);

        // isi pilihan
        btnA.setText("A. " + safeChoice(q, 0));
        btnB.setText("B. " + safeChoice(q, 1));
        btnC.setText("C. " + safeChoice(q, 2));
        btnD.setText("D. " + safeChoice(q, 3));

        // reset timer 60s tiap soal
        timeLeft = QUESTION_TIME_MS;
        startTimer();
    }

    private String safeChoice(Question q, int pos) {
        if (q.choices == null || q.choices.length <= pos) return "";
        return q.choices[pos];
    }

    private void answer(int selectedIndex) {
        stopTimer();

        Question q = questions.get(index);
        if (selectedIndex == q.answerIndex) {
            correct++;
        }

        index++;
        showQuestion();
    }

    private void startTimer() {
        stopTimer();

        timer = new CountDownTimer(timeLeft, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timeLeft = millisUntilFinished;
                long sec = millisUntilFinished / 1000;
                tvTimer.setText(sec + "s");
            }

            @Override
            public void onFinish() {
                tvTimer.setText("0s");
                // waktu habis -> lanjut soal berikutnya
                index++;
                showQuestion();
            }
        }.start();
    }

    private void stopTimer() {
        if (timer != null) {
            timer.cancel();
            timer = null;
        }
    }

    private void finishQuiz() {
        stopTimer();

        Intent i = new Intent(QuizActivity.this, ResultActivity.class);

        // score: jumlah benar, total: total soal
        i.putExtra("score", correct);
        i.putExtra("total", TOTAL_QUESTIONS);

        // biar ga balik lagi ke quiz via back
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);

        startActivity(i);
        finish();
    }

    @Override
    protected void onDestroy() {
        stopTimer();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        // samain behavior dengan tombol kembali
        btnKembali.performClick();
    }
}

package com.quizku.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.quizku.app.R;
import com.quizku.app.util.LocaleHelper;
import com.quizku.app.util.Prefs;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        String lang = Prefs.getLang(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, lang));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        Button btnMulai = findViewById(R.id.btnMulai);
        Button btnKeluar = findViewById(R.id.btnKeluar);

        btnMulai.setOnClickListener(v -> startActivity(new Intent(this, QuizActivity.class)));
        btnKeluar.setOnClickListener(v -> finishAffinity());
    }
}

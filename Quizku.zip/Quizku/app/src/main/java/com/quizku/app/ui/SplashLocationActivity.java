package com.quizku.app.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.quizku.app.R;
import com.quizku.app.util.Prefs;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SplashLocationActivity extends AppCompatActivity {

    private static final String TAG = "SPLASH";

    // Biar ga loading terus: kalau lewat 10 detik ga dapet lokasi -> lanjut pakai bahasa tersimpan
    private static final long TIMEOUT_MS = 10_000;

    private FusedLocationProviderClient fused;
    private ActivityResultLauncher<String[]> permissionLauncher;

    private TextView tvStatus;
    private ProgressBar progress;

    private boolean finished = false;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable timeoutRunnable = this::onDetectTimeout;

    private LocationCallback singleUpdateCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_location);

        tvStatus = findViewById(R.id.tvStatus);
        progress = findViewById(R.id.progress);

        fused = LocationServices.getFusedLocationProviderClient(this);

        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    boolean fine = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION));
                    boolean coarse = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));
                    if (fine || coarse) {
                        Log.d(TAG, "permission ok -> detectCountry()");
                        detectCountry();
                    } else {
                        Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show();
                        goNextWithSavedLang();
                    }
                }
        );

        Log.d(TAG, "SPLASH OPEN");
        tvStatus.setText(getString(R.string.detecting_location));
        progress.setVisibility(View.VISIBLE);

        // start timeout guard
        handler.postDelayed(timeoutRunnable, TIMEOUT_MS);

        if (hasLocationPermission()) {
            detectCountry();
        } else {
            requestLocationPermission();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(timeoutRunnable);
        stopSingleUpdate();
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        permissionLauncher.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });
    }

    private void detectCountry() {
        Log.d(TAG, "detectCountry CALLED");

        // 1) coba last location dulu (sering cepat kalau emulator udah punya lokasi)
        fused.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (location != null) {
                        Log.d(TAG, "getLastLocation OK: " + location.getLatitude() + "," + location.getLongitude());
                        onGotLocation(location);
                    } else {
                        Log.d(TAG, "getLastLocation NULL -> requestSingleUpdate()");
                        requestSingleUpdate();
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "getLastLocation FAIL -> requestSingleUpdate()", e);
                    requestSingleUpdate();
                });
    }

    /**
     * Ini kunci supaya ga loading terus:
     * Kalau lastLocation null, kita minta 1x update lokasi, lalu stop.
     */
    private void requestSingleUpdate() {
        try {
            LocationRequest req = LocationRequest.create();
            req.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
            req.setInterval(1000);
            req.setFastestInterval(500);
            req.setNumUpdates(1); // 1x saja

            singleUpdateCallback = new LocationCallback() {
                @Override
                public void onLocationResult(@NonNull LocationResult locationResult) {
                    Location loc = locationResult.getLastLocation();
                    Log.d(TAG, "requestSingleUpdate result: " + (loc != null ? "OK" : "NULL"));
                    stopSingleUpdate();
                    if (loc != null) onGotLocation(loc);
                    else onDetectFailed();
                }
            };

            fused.requestLocationUpdates(req, singleUpdateCallback, Looper.getMainLooper());
            Log.d(TAG, "requestSingleUpdate started");
        } catch (SecurityException se) {
            Log.e(TAG, "requestSingleUpdate security exception", se);
            onDetectFailed();
        }
    }

    private void stopSingleUpdate() {
        if (singleUpdateCallback != null) {
            fused.removeLocationUpdates(singleUpdateCallback);
            singleUpdateCallback = null;
        }
    }

    private void onGotLocation(@NonNull Location loc) {
        if (finished) return;

        String countryCode = reverseCountryCode(loc.getLatitude(), loc.getLongitude());
        Log.d(TAG, "CountryCode = " + countryCode);

        if (countryCode == null || countryCode.trim().isEmpty()) {
            onDetectFailed();
            return;
        }

        String lang = mapCountryToLang(countryCode);
        Log.d(TAG, "Mapped lang = " + lang);

        // simpan bahasa hasil geo
        Prefs.setLang(this, lang);

        // lanjut (restart activity target biar apply locale)
        goNextRestart();
    }

    private void onDetectFailed() {
        if (finished) return;
        Toast.makeText(this, getString(R.string.location_failed), Toast.LENGTH_SHORT).show();
        goNextWithSavedLang();
    }

    private void onDetectTimeout() {
        if (finished) return;
        Log.d(TAG, "TIMEOUT -> goNextWithSavedLang()");
        goNextWithSavedLang();
    }

    private void goNextWithSavedLang() {
        // jangan ubah Prefs, pakai bahasa yang sudah tersimpan sebelumnya
        goNextRestart();
    }

    /**
     * Restart WelcomeActivity biar bahasa berubah beneran.
     */
    private void goNextRestart() {
        if (finished) return;
        finished = true;

        handler.removeCallbacks(timeoutRunnable);
        stopSingleUpdate();

        progress.setVisibility(View.GONE);

        Intent i = new Intent(this, WelcomeActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(i);
        finish();
    }

    private String reverseCountryCode(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> list = geocoder.getFromLocation(lat, lon, 1);
            if (list != null && !list.isEmpty()) {
                return list.get(0).getCountryCode(); // "DE", "NL", "JP", "ID"
            }
        } catch (IOException e) {
            Log.e(TAG, "Geocoder error", e);
        } catch (Exception e) {
            Log.e(TAG, "Geocoder unknown error", e);
        }
        return null;
    }

    private String mapCountryToLang(String cc) {
        cc = cc.toUpperCase(Locale.ROOT);

        switch (cc) {
            case "DE":
                return "de";
            case "NL":
                return "nl";
            case "JP":
                return "ja";
            case "ID":
            default:
                return "in"; // Indonesia
        }
    }
}

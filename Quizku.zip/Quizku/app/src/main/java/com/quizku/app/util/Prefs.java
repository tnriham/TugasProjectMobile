package com.quizku.app.util;

import android.content.Context;
import android.content.SharedPreferences;

public class Prefs {

    private static final String SP = "quizku_prefs";
    private static final String KEY_LANG = "lang";
    private static final String DEFAULT = "in";

    private static SharedPreferences sp(Context c) {
        return c.getSharedPreferences(SP, Context.MODE_PRIVATE);
    }

    public static void setLang(Context c, String lang) {
        sp(c).edit().putString(KEY_LANG, lang).apply();
    }

    public static String getLang(Context c) {
        return sp(c).getString(KEY_LANG, DEFAULT);
    }
}

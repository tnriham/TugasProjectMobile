package com.quizku.app.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import com.quizku.app.R;
import com.quizku.app.util.LocaleHelper;
import com.quizku.app.util.Prefs;
import com.quizku.app.worker.DailyReminderWorker;

import java.util.Calendar;
import java.util.concurrent.TimeUnit;

public class WelcomeActivity extends AppCompatActivity {

    private ActivityResultLauncher<String> notifPermLauncher;
    private ImageView ivFlag;

    @Override
    protected void attachBaseContext(android.content.Context newBase) {
        String lang = Prefs.getLang(newBase);
        super.attachBaseContext(LocaleHelper.setLocale(newBase, lang));
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome);

        ivFlag = findViewById(R.id.ivFlag);
        Button btnLanjut = findViewById(R.id.btnLanjut);

        // Launcher permission notif (Android 13+)
        notifPermLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(),
                granted -> scheduleDailyNotif()
        );

        requestNotifPermissionIfNeeded();

        btnLanjut.setOnClickListener(v -> {
            startActivity(new Intent(this, MenuActivity.class));
            finish();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyFlagFromLang();
    }

    private void applyFlagFromLang() {
        String lang = Prefs.getLang(this);

        int resFlag = R.drawable.flag_id; // default Indonesia
        if ("de".equals(lang)) resFlag = R.drawable.flag_de;
        else if ("ja".equals(lang)) resFlag = R.drawable.flag_jp;
        else if ("nl".equals(lang)) resFlag = R.drawable.flag_nl;

        ivFlag.setImageResource(resFlag);
    }

    private void requestNotifPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
            } else {
                scheduleDailyNotif();
            }
        } else {
            scheduleDailyNotif();
        }
    }

    private void scheduleDailyNotif() {
        Calendar now = Calendar.getInstance();

        Calendar target = Calendar.getInstance();
        target.set(Calendar.HOUR_OF_DAY, 20);
        target.set(Calendar.MINUTE, 0);
        target.set(Calendar.SECOND, 0);
        target.set(Calendar.MILLISECOND, 0);

        long delay = target.getTimeInMillis() - now.getTimeInMillis();
        if (delay < 0) delay += TimeUnit.DAYS.toMillis(1);

        PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(
                DailyReminderWorker.class,
                24, TimeUnit.HOURS
        ).setInitialDelay(delay, TimeUnit.MILLISECONDS).build();

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "daily_quizku_reminder",
                ExistingPeriodicWorkPolicy.UPDATE,
                req
        );
    }
}

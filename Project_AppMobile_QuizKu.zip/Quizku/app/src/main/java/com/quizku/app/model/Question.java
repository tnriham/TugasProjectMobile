package com.quizku.app.model;

public class Question {
    public final String question;
    public final String[] choices;
    public final int answerIndex;

    public Question(String question, String[] choices, int answerIndex) {
        this.question = question;
        this.choices = choices;
        this.answerIndex = answerIndex;
    }
}

package com.quizku.app.model;

import android.content.Context;

import com.quizku.app.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class QuestionBank {

    public static List<Question> getQuestions(Context c) {
        List<Question> q = new ArrayList<>();

        q.add(new Question(
                c.getString(R.string.q1_question),
                new String[]{
                        c.getString(R.string.q1_a),
                        c.getString(R.string.q1_b),
                        c.getString(R.string.q1_c),
                        c.getString(R.string.q1_d)
                },
                0
        ));

        q.add(new Question(
                c.getString(R.string.q2_question),
                new String[]{
                        c.getString(R.string.q2_a),
                        c.getString(R.string.q2_b),
                        c.getString(R.string.q2_c),
                        c.getString(R.string.q2_d)
                },
                1
        ));

        q.add(new Question(
                c.getString(R.string.q3_question),
                new String[]{
                        c.getString(R.string.q3_a),
                        c.getString(R.string.q3_b),
                        c.getString(R.string.q3_c),
                        c.getString(R.string.q3_d)
                },
                2
        ));

        q.add(new Question(
                c.getString(R.string.q4_question),
                new String[]{
                        c.getString(R.string.q4_a),
                        c.getString(R.string.q4_b),
                        c.getString(R.string.q4_c),
                        c.getString(R.string.q4_d)
                },
                0
        ));

        q.add(new Question(
                c.getString(R.string.q5_question),
                new String[]{
                        c.getString(R.string.q5_a),
                        c.getString(R.string.q5_b),
                        c.getString(R.string.q5_c),
                        c.getString(R.string.q5_d)
                },
                2
        ));

        Collections.shuffle(q);
        return q;
    }
}

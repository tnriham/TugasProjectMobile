package com.quizku.app.ui;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.quizku.app.R;
import com.quizku.app.util.Prefs;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class SplashLocationActivity extends AppCompatActivity {

    private static final String TAG = "SPLASH";

    // tampil splash dulu baru detect
    private static final long SPLASH_DELAY_MS = 1300;

    // timeout detect biar ga loading terus
    private static final long DETECT_TIMEOUT_MS = 10000;

    private ImageView ivLogo;
    private ProgressBar progress;

    private FusedLocationProviderClient fused;
    private ActivityResultLauncher<String[]> permissionLauncher;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean finished = false;

    private LocationCallback singleUpdateCallback;

    private final Runnable detectTimeoutRunnable = () -> {
        if (finished) return;
        Log.d(TAG, "TIMEOUT -> go next (saved lang)");
        Toast.makeText(this, getString(R.string.location_failed), Toast.LENGTH_SHORT).show();
        goNext();
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_location);

        ivLogo = findViewById(R.id.ivLogo);
        progress = findViewById(R.id.progress);

        fused = LocationServices.getFusedLocationProviderClient(this);

        // Animasi logo biar keren (pulse)
        startLogoPulse();

        // awal: cuma tampilin logo + loading (tanpa teks)
        progress.setVisibility(View.VISIBLE);

        permissionLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestMultiplePermissions(),
                result -> {
                    boolean fine = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_FINE_LOCATION));
                    boolean coarse = Boolean.TRUE.equals(result.get(Manifest.permission.ACCESS_COARSE_LOCATION));

                    if (fine || coarse) {
                        Log.d(TAG, "permission OK -> startDetect()");
                        startDetectWithTimeout();
                    } else {
                        Log.d(TAG, "permission DENIED -> go next (saved lang)");
                        Toast.makeText(this, getString(R.string.permission_denied), Toast.LENGTH_SHORT).show();
                        goNext();
                    }
                }
        );

        Log.d(TAG, "SPLASH OPEN");

        // ✅ splash dulu baru mulai flow lokasi
        handler.postDelayed(this::beginLocationFlow, SPLASH_DELAY_MS);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        handler.removeCallbacks(detectTimeoutRunnable);
        stopSingleUpdate();
    }

    private void beginLocationFlow() {
        if (finished) return;

        if (hasLocationPermission()) {
            startDetectWithTimeout();
        } else {
            requestLocationPermission();
        }
    }

    private boolean hasLocationPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestLocationPermission() {
        permissionLauncher.launch(new String[]{
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
        });
    }

    private void startDetectWithTimeout() {
        handler.removeCallbacks(detectTimeoutRunnable);
        handler.postDelayed(detectTimeoutRunnable, DETECT_TIMEOUT_MS);
        detectCountryApi24Safe();
    }

    /**
     * API 24 aman:
     * 1) coba getLastLocation
     * 2) kalau null -> requestLocationUpdates 1x (numUpdates=1)
     */
    private void detectCountryApi24Safe() {
        Log.d(TAG, "detectCountryApi24Safe CALLED");

        fused.getLastLocation()
                .addOnSuccessListener(location -> {
                    if (finished) return;

                    if (location != null) {
                        Log.d(TAG, "getLastLocation OK: " + location.getLatitude() + "," + location.getLongitude());
                        onGotLocation(location);
                    } else {
                        Log.d(TAG, "getLastLocation NULL -> requestSingleUpdate()");
                        requestSingleUpdate();
                    }
                })
                .addOnFailureListener(e -> {
                    if (finished) return;
                    Log.e(TAG, "getLastLocation FAIL -> requestSingleUpdate()", e);
                    requestSingleUpdate();
                });
    }

    private void requestSingleUpdate() {
        try {
            LocationRequest req = LocationRequest.create();
            req.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
            req.setInterval(1000);
            req.setFastestInterval(500);
            req.setNumUpdates(1); // 1x saja

            singleUpdateCallback = new LocationCallback() {
                @Override
                public void onLocationResult(@NonNull LocationResult locationResult) {
                    if (finished) return;

                    Location loc = locationResult.getLastLocation();
                    Log.d(TAG, "singleUpdate result: " + (loc != null ? "OK" : "NULL"));

                    stopSingleUpdate();

                    if (loc != null) onGotLocation(loc);
                    else onDetectFailed();
                }
            };

            fused.requestLocationUpdates(req, singleUpdateCallback, Looper.getMainLooper());
            Log.d(TAG, "requestSingleUpdate started");
        } catch (SecurityException se) {
            Log.e(TAG, "requestSingleUpdate security exception", se);
            onDetectFailed();
        }
    }

    private void stopSingleUpdate() {
        if (singleUpdateCallback != null) {
            fused.removeLocationUpdates(singleUpdateCallback);
            singleUpdateCallback = null;
        }
    }

    private void onGotLocation(@NonNull Location loc) {
        if (finished) return;

        String countryCode = reverseCountryCode(loc.getLatitude(), loc.getLongitude());
        Log.d(TAG, "CountryCode = " + countryCode);

        if (countryCode == null || countryCode.trim().isEmpty()) {
            onDetectFailed();
            return;
        }

        String lang = mapCountryToLang(countryCode);
        Log.d(TAG, "Mapped lang = " + lang);

        Prefs.setLang(this, lang);

        goNext();
    }

    private void onDetectFailed() {
        if (finished) return;

        Log.d(TAG, "onDetectFailed -> go next (saved lang)");
        Toast.makeText(this, getString(R.string.location_failed), Toast.LENGTH_SHORT).show();
        goNext();
    }

    private void goNext() {
        if (finished) return;
        finished = true;

        handler.removeCallbacks(detectTimeoutRunnable);
        stopSingleUpdate();

        progress.setVisibility(View.GONE);

        // ke welcome, locale akan kebaca dari Prefs di attachBaseContext Welcome
        startActivity(new Intent(this, WelcomeActivity.class));
        finish();
    }

    private String reverseCountryCode(double lat, double lon) {
        try {
            Geocoder geocoder = new Geocoder(this, Locale.getDefault());
            List<Address> list = geocoder.getFromLocation(lat, lon, 1);
            if (list != null && !list.isEmpty()) {
                return list.get(0).getCountryCode(); // DE / NL / JP / ID
            }
        } catch (IOException e) {
            Log.e(TAG, "Geocoder error", e);
        } catch (Exception e) {
            Log.e(TAG, "Geocoder unknown error", e);
        }
        return null;
    }

    private String mapCountryToLang(String cc) {
        cc = cc.toUpperCase(Locale.ROOT);
        switch (cc) {
            case "DE": return "de";
            case "NL": return "nl";
            case "JP": return "ja";
            case "ID":
            default:   return "in"; // kalau kamu udah ganti ke "id", ubah di sini juga
        }
    }

    private void startLogoPulse() {
        // scaleX pulse
        ObjectAnimator sx = ObjectAnimator.ofFloat(ivLogo, View.SCALE_X, 1.0f, 1.06f);
        sx.setDuration(900);
        sx.setRepeatCount(ObjectAnimator.INFINITE);
        sx.setRepeatMode(ObjectAnimator.REVERSE);
        sx.setInterpolator(new AccelerateDecelerateInterpolator());
        sx.start();

        // scaleY pulse
        ObjectAnimator sy = ObjectAnimator.ofFloat(ivLogo, View.SCALE_Y, 1.0f, 1.06f);
        sy.setDuration(900);
        sy.setRepeatCount(ObjectAnimator.INFINITE);
        sy.setRepeatMode(ObjectAnimator.REVERSE);
        sy.setInterpolator(new AccelerateDecelerateInterpolator());
        sy.start();
    }
}
